// src/components/ResultScreen.jsx
import { useVideoStore } from '../store/videoStore.js';
import VideoPlayer  from './VideoPlayer.jsx';
import SceneList    from './SceneList.jsx';
import ExportPanel  from './ExportPanel.jsx';
import SNSTags      from './SNSTags.jsx';

export default function ResultScreen() {
  const { script, audioBuffers, reset, setShowResult } = useVideoStore();

  const totalSec = script?.scenes?.reduce((a, s) => a + (s.duration || 0), 0) || 0;
  const hasAudio = audioBuffers?.some(b => b);

  const goBack = () => { setShowResult(false); };
  const doReset = () => { reset(); };

  return (
    <div className="result-wrap">
      <div className="result-inner">
        {/* 헤더 */}
        <div className="result-header">
          <button className="result-back-btn" onClick={goBack}>
            <i className="fas fa-arrow-left" />
          </button>
          <div className="result-title-box">
            <p className="result-label">생성 완료</p>
            <p className="result-sub">{script?.scenes?.length || 0}개 씬 · {totalSec.toFixed(1)}초</p>
          </div>
          <div className="badge-group">
            <div className="audio-badge">
              <i className="fas fa-microphone-alt" />
              <span>{hasAudio ? 'AI 보이스' : '무음'}</span>
            </div>
          </div>
        </div>

        {/* 영상 플레이어 */}
        <VideoPlayer />

        {/* 씬 목록 */}
        <SceneList />

        {/* 저장 패널 */}
        <ExportPanel />

        {/* SNS 태그 */}
        {script && <SNSTags script={script} />}

        {/* 다시 만들기 */}
        <button className="re-btn" onClick={doReset}>
          <i className="fas fa-redo" /> 다시 만들기
        </button>
      </div>
    </div>
  );
}


// src/components/SNSTags.jsx (인라인으로 포함)
export function SNSTags({ script }) {
  if (!script) return null;

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      useVideoStore.getState().addToast('클립보드에 복사됐습니다!', 'ok');
    } catch {
      useVideoStore.getState().addToast('복사 실패', 'err');
    }
  };

  const tags = [
    { badge: 'naver',   label: 'N 클립',  limit: '300자 이내', text: script.naver_clip_tags || '' },
    { badge: 'youtube', label: '▶ 쇼츠',  limit: '100자 이내', text: script.youtube_shorts_tags || '' },
    { badge: 'insta',   label: '◎ 릴스',  limit: '캡션 + 태그', text: script.instagram_caption || '' },
    { badge: 'tiktok',  label: '♪ 틱톡',  limit: '5개',         text: script.tiktok_tags || '' },
  ];

  return (
    <div className="sns-wrap">
      <p className="sns-title"><i className="fas fa-hashtag" /> SNS 플랫폼별 태그</p>
      {tags.map((t, i) => (
        <div key={i} className="sns-card">
          <div className="sns-card-head">
            <span className={`sns-badge ${t.badge}`}>{t.label}</span>
            <span className="sns-limit">{t.limit}</span>
            <button className="sns-copy-btn" onClick={() => copy(t.text)}>
              <i className="fas fa-copy" /> 복사
            </button>
          </div>
          <div className="sns-text">{t.text}</div>
        </div>
      ))}
    </div>
  );
}
